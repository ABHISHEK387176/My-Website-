// Simple console message for testing JavaScript functionality
console.log("Welcome to Code with Abhi's website!");